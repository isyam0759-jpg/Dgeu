package com.sirenhead.entity;

import com.sirenhead.client.SirenClientHooks;
import com.sirenhead.config.SirenConfig;
import com.sirenhead.registry.ModEffects;
import com.sirenhead.registry.ModSounds;
import com.sirenhead.util.SirenFx;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

/**
 * Tiang pengeras suara (ash:figurehead). Setiap 10 detik menjerit; setiap 2 detik memancarkan gelombang
 * yang melukai semua makhluk dalam radius. Hilang sendiri setelah umur habis.
 */
public class FigureheadEntity extends Mob implements GeoEntity {
    public static final byte EVENT_PULSE = 100;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int maxLife = 3000;

    public FigureheadEntity(EntityType<? extends FigureheadEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 1024.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.MOVEMENT_SPEED, 0.0);
    }

    public void setMaxLife(int ticks) {
        this.maxLife = ticks;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;
        ServerLevel sl = (ServerLevel) this.level();
        if (this.tickCount > maxLife) {
            this.discard();
            return;
        }
        // jeritan tiap 10 detik, denyut tiap 2 detik (animation.r asli)
        if (this.tickCount % 200 == 5) {
            sl.playSound(null, this.getX(), this.getY() + 15, this.getZ(), ModSounds.SCREAM.get(),
                    SoundSource.HOSTILE, 16.0F, 1.0F);
        }
        if (this.tickCount % 40 == 5) {
            pulse(sl);
        }
    }

    private void pulse(ServerLevel sl) {
        double r = SirenConfig.FIGUREHEAD_RADIUS.get();
        float dmg = SirenConfig.FIGUREHEAD_DAMAGE.get().floatValue();
        AABB box = new AABB(getX() - r, getY() - r, getZ() - r, getX() + r, getY() + r, getZ() + r);
        List<LivingEntity> list = sl.getEntitiesOfClass(LivingEntity.class, box,
                e -> e.isAlive() && !(e instanceof SirenHeadEntity) && !(e instanceof FigureheadEntity));
        for (LivingEntity e : list) {
            if (e.distanceToSqr(this) > r * r) continue;
            e.hurt(this.damageSources().sonicBoom(this), dmg);
            if (e instanceof Player && e.isAlive()) {
                e.addEffect(new MobEffectInstance(ModEffects.DEAFENED.get(), 100));
            }
        }
        SirenFx.pulse(sl, this.position(), r);
        sl.broadcastEntityEvent(this, EVENT_PULSE);
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == EVENT_PULSE) {
            SirenClientHooks.shake(this.position().add(0, 7, 0), 3.0F, 14, 96.0);
        } else {
            super.handleEntityEvent(id);
        }
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return source.is(DamageTypes.IN_WALL) || source.is(DamageTypes.FALL) || super.isInvulnerableTo(source);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return false;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        return 13.0F;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        return this.getBoundingBox().inflate(36.0, 40.0, 36.0);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MaxLife", maxLife);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("MaxLife")) maxLife = tag.getInt("MaxLife");
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 0, this::controller));
    }

    private PlayState controller(AnimationState<FigureheadEntity> state) {
        // sama seperti addon asli: Figurehead statis, tanpa animasi
        return PlayState.STOP;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
