package com.sirenhead.entity;

import com.sirenhead.client.SirenClientHooks;
import com.sirenhead.config.SirenConfig;
import com.sirenhead.registry.ModEffects;
import com.sirenhead.registry.ModEntities;
import com.sirenhead.registry.ModParticles;
import com.sirenhead.registry.ModSounds;
import com.sirenhead.util.SirenFx;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.AbstractIllager;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Siren Head. Port dari ash:sirenhead (Bedrock): HP 80000, hitbox 2x25, mengejar pemain/golem/illager/villager,
 * menghancurkan kayu, alarm saat santai, musik kejar, hentakan (stomp), terkam (eat) dan event cincin Figurehead.
 */
public class SirenHeadEntity extends Monster implements GeoEntity {
    public static final byte EVENT_STOMP = 100;
    public static final byte EVENT_EAT = 101;

    public static final int STATE_NONE = 0;
    public static final int STATE_STOMP = 1;
    public static final int STATE_EAT = 2;

    private static final EntityDataAccessor<Boolean> DATA_CHASING =
            SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_TALKING =
            SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(SirenHeadEntity.class, EntityDataSerializers.INT);

    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.sirenhead_anl3ty.idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("animation.sirenhead_anl3ty.walk");
    private static final RawAnimation RUN = RawAnimation.begin().thenLoop("animation.sirenhead_anl3ty.run");
    private static final RawAnimation TALK = RawAnimation.begin().thenLoop("animation.sirenhead_anl3ty.talking_idle");
    private static final RawAnimation STOMP = RawAnimation.begin().thenPlay("animation.sirenhead_anl3ty.stomp");
    private static final RawAnimation EAT = RawAnimation.begin().thenPlay("animation.sirenhead_anl3ty.eat");

    /** Durasi (detik) tiap klip alarm_0..alarm_16, dipakai untuk lamanya animasi bicara. */
    private static final double[] ALARM_SECONDS = {52.48, 127.13, 177.61, 27.75, 27.16, 122.65, 27.0, 26.87, 15.58, 8.85, 83.99, 31.81, 10.84, 111.97, 29.58, 68.97, 121.28};

    /** Posisi 10 Figurehead relatif terhadap Siren Head (dari script asli). */
    private static final int[][] RING_OFFSETS = {
            {38, 3}, {31, 23}, {17, 36}, {2, 41}, {-22, 31},
            {-37, 17}, {-28, 1}, {-32, -23}, {-19, -37}, {3, -38}
    };

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bossEvent = new ServerBossEvent(this.getDisplayName(),
            BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);

    private int attackCooldown;
    private int specialCharge;
    private int stateTicks;
    private int idleTicks;
    private int talkTicks;
    private int currentAlarm = -1;
    private int alarmCooldown;
    private int ringTicks;
    private UUID eatTargetId;
    private double eatDirX;
    private double eatDirZ;
    private double eatBaseY;
    private final List<UUID> figureheads = new ArrayList<>();

    public SirenHeadEntity(EntityType<? extends SirenHeadEntity> type, Level level) {
        super(type, level);
        this.xpReward = 1000;
        this.setMaxUpStep(4.0F);
        try {
            this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(SirenConfig.CHASE_SPEED.get());
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(SirenConfig.ATTACK_DAMAGE.get());
            this.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(SirenConfig.FOLLOW_RANGE.get());
        } catch (IllegalStateException ignored) {
            // config belum dimuat (mis. saat registrasi); nilai default atribut dipakai
        }
        this.bossEvent.setVisible(safeBossBar());
    }

    private static boolean safeBossBar() {
        try {
            return SirenConfig.BOSS_BAR.get();
        } catch (IllegalStateException e) {
            return true;
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1024.0)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.MOVEMENT_SPEED, 0.60)
                .add(Attributes.FOLLOW_RANGE, 100.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    public static boolean checkSpawnRules(EntityType<SirenHeadEntity> type, ServerLevelAccessor level,
                                          MobSpawnType reason, BlockPos pos, RandomSource random) {
        if ((reason == MobSpawnType.NATURAL || reason == MobSpawnType.CHUNK_GENERATION)
                && !SirenConfig.NATURAL_SPAWN.get()) {
            return false;
        }
        if (level.getDifficulty() == Difficulty.PEACEFUL) return false;
        if (!level.canSeeSky(pos)) return false;
        if (!level.getEntitiesOfClass(SirenHeadEntity.class, new AABB(pos).inflate(256)).isEmpty()) return false;
        return Monster.isDarkEnoughToSpawn(level, pos, random) && Mob.checkMobSpawnRules(type, level, reason, pos, random);
    }

    // ------------------------------------------------------------------ data / ai

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_CHASING, false);
        this.entityData.define(DATA_STATE, STATE_NONE);
        this.entityData.define(DATA_TALKING, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new SirenGoals.ChaseGoal(this));
        this.goalSelector.addGoal(5, new SirenGoals.WanderGoal(this));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 60.0F));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false,
                e -> e instanceof Player || e instanceof SnowGolem || e instanceof IronGolem
                        || e instanceof AbstractIllager || e instanceof AbstractVillager));
    }

    public boolean isChasing() {
        return this.entityData.get(DATA_CHASING);
    }

    /** Sedang mengeluarkan suara sirene: animasi bicara menyala. */
    public boolean isTalking() {
        return state() == STATE_NONE && !isChasing() && this.entityData.get(DATA_TALKING);
    }

    public int state() {
        return this.entityData.get(DATA_STATE);
    }

    /** Sedang menghentak / menerkam: diam di tempat. */
    public boolean isBusy() {
        return state() != STATE_NONE;
    }

    private void setState(int s) {
        this.entityData.set(DATA_STATE, s);
    }

    // ------------------------------------------------------------------ health scaling

    private float healthScale() {
        double eff = Math.max(1024.0, SirenConfig.EFFECTIVE_HEALTH.get());
        return (float) (1024.0 / eff);
    }

    @Override
    protected void actuallyHurt(DamageSource source, float amount) {
        super.actuallyHurt(source, amount * healthScale());
    }

    @Override
    public void heal(float amount) {
        super.heal(amount * healthScale());
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return source.is(DamageTypes.IN_WALL) || source.is(DamageTypes.FALL) || source.is(DamageTypes.DROWN)
                || source.is(DamageTypes.CRAMMING) || super.isInvulnerableTo(source);
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean canBreatheUnderwater() {
        return true;
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return distanceSqr > 300.0 * 300.0;
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        return 23.0F;
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        // bone "sirens" melebar jauh dari hitbox; perbesar agar model tidak hilang saat di tepi layar
        return this.getBoundingBox().inflate(36.0, 40.0, 36.0);
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.DEAD.get();
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        // langkah ditangani klien (keyframe "step" di animasi) agar sinkron dengan kaki
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    // ------------------------------------------------------------------ boss bar

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        this.bossEvent.setName(this.getDisplayName());
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            clientTick();
        } else {
            serverTick((ServerLevel) this.level());
        }
    }

    private void clientTick() {
        // langkah, debu, dan getaran dipicu keyframe animasi (lihat registerControllers) tepat di kaki
        SirenClientHooks.tickSiren(this);
    }

    private void serverTick(ServerLevel sl) {
        this.bossEvent.setProgress(Mth.clamp(this.getHealth() / this.getMaxHealth(), 0.0F, 1.0F));
        LivingEntity target = this.getTarget();
        boolean chasing = target != null && target.isAlive();
        if (this.entityData.get(DATA_CHASING) != chasing) {
            this.entityData.set(DATA_CHASING, chasing);
        }
        if (attackCooldown > 0) attackCooldown--;

        tickRing(sl);

        if (chasing && talkTicks > 0) {
            stopAlarm(sl);
        }
        if (alarmCooldown > 0) alarmCooldown--;
        if (talkTicks > 0) talkTicks--;
        boolean talking = talkTicks > 0;
        if (this.entityData.get(DATA_TALKING) != talking) {
            this.entityData.set(DATA_TALKING, talking);
        }

        if (state() != STATE_NONE) {
            tickSpecial(sl);
            return;
        }

        if (this.tickCount % 6 == 0 && SirenConfig.BREAK_BLOCKS.get()) {
            breakBlocks(sl);
        }

        if (chasing) {
            idleTicks = 0;
            double hd = horizontalDistance(target);
            if (attackCooldown <= 0 && hd <= 6.0 + target.getBbWidth() * 0.5) {
                this.swing(InteractionHand.MAIN_HAND);
                this.doHurtTarget(target);
                attackCooldown = SirenConfig.ATTACK_COOLDOWN_TICKS.get();
            }
            if (hd <= 20.0 && Math.abs(target.getY() - this.getY()) <= 40.0) {
                if (++specialCharge >= SirenConfig.SPECIAL_INTERVAL_TICKS.get()) {
                    specialCharge = 0;
                    if (this.random.nextBoolean()) startStomp(sl); else startEat(sl, target);
                }
            } else {
                specialCharge = 0;
            }
        } else {
            specialCharge = 0;
            idleTicks++;
            // alarm: 20 detik setelah tidak punya target, lalu sekitar tiap 100 detik.
            // Animasi bicara menyala selama klip suara berbunyi dan berhenti saat klip habis.
            if (idleTicks >= 400 && alarmCooldown <= 0 && talkTicks <= 0) {
                int i = this.random.nextInt(ModSounds.ALARMS.size());
                currentAlarm = i;
                sl.playSound(null, this.getX(), this.getY() + 20, this.getZ(), ModSounds.ALARMS.get(i).get(),
                        SoundSource.HOSTILE, 16.0F, 1.0F);
                talkTicks = (int) Math.ceil(ALARM_SECONDS[i] * 20.0);
                alarmCooldown = Math.max(2000, talkTicks + 400);
            }
        }
    }

    /** Mulai mengejar: alarm yang sedang berbunyi dihentikan agar tidak menimpa musik kejar. */
    private void stopAlarm(ServerLevel sl) {
        if (currentAlarm >= 0) {
            ClientboundStopSoundPacket packet =
                    new ClientboundStopSoundPacket(ModSounds.ALARMS.get(currentAlarm).getId(), SoundSource.HOSTILE);
            for (ServerPlayer p : sl.players()) {
                p.connection.send(packet);
            }
        }
        currentAlarm = -1;
        talkTicks = 0;
    }

    private double horizontalDistance(Entity e) {
        double dx = e.getX() - this.getX();
        double dz = e.getZ() - this.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    // ------------------------------------------------------------------ special attacks

    /** Dipakai juga oleh /sirenhead stomp. */
    public void startStomp(ServerLevel sl) {
        if (isBusy()) return;
        setState(STATE_STOMP);
        stateTicks = 0;
        this.triggerAnim("special", "stomp");
        sl.playSound(null, this.getX(), this.getY() + 5, this.getZ(), ModSounds.STOMP.get(), SoundSource.HOSTILE, 16.0F, 1.0F);
    }

    /** Dipakai juga oleh /sirenhead eat. */
    public void startEat(ServerLevel sl, LivingEntity target) {
        if (isBusy()) return;
        eatTargetId = target.getUUID();
        eatBaseY = this.getY();
        double dx = target.getX() - this.getX();
        double dz = target.getZ() - this.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0E-4) len = 1.0;
        eatDirX = dx / len;
        eatDirZ = dz / len;
        setState(STATE_EAT);
        stateTicks = 0;
        this.triggerAnim("special", "eat");
        sl.playSound(null, this.getX(), this.getY() + 10, this.getZ(), ModSounds.JUMPSCARE.get(), SoundSource.HOSTILE, 16.0F, 1.0F);
        sl.broadcastEntityEvent(this, EVENT_EAT);
    }

    private void tickSpecial(ServerLevel sl) {
        stateTicks++;
        this.setDeltaMovement(0.0, this.getDeltaMovement().y, 0.0);
        this.getNavigation().stop();
        if (state() == STATE_STOMP) {
            if (stateTicks == 20) stompImpact(sl);
            if (stateTicks >= 40) endSpecial();
        } else if (state() == STATE_EAT) {
            tickEat(sl);
        }
    }

    private void endSpecial() {
        setState(STATE_NONE);
        stateTicks = 0;
        eatTargetId = null;
        attackCooldown = Math.max(attackCooldown, 40);
    }

    private void stompImpact(ServerLevel sl) {
        double r = SirenConfig.STOMP_RADIUS.get();
        double flat = SirenConfig.STOMP_FLAT_DAMAGE.get();
        double pct = SirenConfig.STOMP_PERCENT_DAMAGE.get();
        boolean all = SirenConfig.STOMP_HITS_ALL_MOBS.get();
        AABB box = new AABB(getX() - r, getY() - r, getZ() - r, getX() + r, getY() + r, getZ() + r);
        List<LivingEntity> victims = sl.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != this && e.isAlive() && !(e instanceof SirenHeadEntity) && !(e instanceof FigureheadEntity)
                        && (all || e instanceof Player));
        for (LivingEntity e : victims) {
            if (e.distanceToSqr(this) > r * r) continue;
            e.invulnerableTime = 0;
            e.hurt(this.damageSources().mobAttack(this), (float) (flat + e.getMaxHealth() * pct));
            if (e instanceof Player && e.isAlive()) {
                e.addEffect(new MobEffectInstance(ModEffects.DEAFENED.get(), 200));
            }
        }
        SirenFx.stomp(sl, SirenFx.footPos(this, true));
        sl.broadcastEntityEvent(this, EVENT_STOMP);
    }

    private void tickEat(ServerLevel sl) {
        Entity found = eatTargetId == null ? null : sl.getEntity(eatTargetId);
        if (!(found instanceof LivingEntity victim) || !victim.isAlive()) {
            endSpecial();
            return;
        }
        float yaw = (float) (Mth.atan2(victim.getZ() - this.getZ(), victim.getX() - this.getX()) * (180.0 / Math.PI)) - 90.0F;
        this.setYRot(yaw);
        this.yBodyRot = yaw;
        this.setYHeadRot(yaw);

        double hx = this.getX() + eatDirX * 12.0;
        double hz = this.getZ() + eatDirZ * 12.0;
        if (stateTicks <= 9 && stateTicks % 3 == 0) {
            int step = stateTicks / 3; // 1..3
            moveVictim(victim, hx, eatBaseY + 4.0 + 20.0 * (step / 4.0), hz);
        } else if (stateTicks >= 12 && stateTicks < 60) {
            moveVictim(victim, hx, eatBaseY + 24.0, hz);
        }

        if (stateTicks == 44) {
            Vec3 p = victim.position().add(0, victim.getBbHeight() * 0.5, 0);
            victim.invulnerableTime = 0;
            victim.hurt(this.damageSources().mobAttack(this), SirenConfig.EAT_DAMAGE.get().floatValue());
            this.heal(SirenConfig.EAT_HEAL.get().floatValue());
            SirenFx.blood(sl, p);
            if (victim.isAlive()) {
                victim.addEffect(new MobEffectInstance(ModEffects.TERROR.get(), 600));
            }
        }
        if (stateTicks >= 60) endSpecial();
    }

    private void moveVictim(LivingEntity v, double x, double y, double z) {
        v.fallDistance = 0.0F;
        v.setDeltaMovement(Vec3.ZERO);
        if (v instanceof ServerPlayer sp) {
            sp.connection.teleport(x, y, z, sp.getYRot(), sp.getXRot());
        } else {
            v.moveTo(x, y, z, v.getYRot(), v.getXRot());
        }
        v.hurtMarked = true;
    }

    // ------------------------------------------------------------------ block breaking

    public static boolean isBreakable(BlockState s) {
        return s.is(BlockTags.LOGS) || s.is(BlockTags.PLANKS) || s.is(BlockTags.LEAVES)
                || s.is(BlockTags.WOODEN_SLABS) || s.is(BlockTags.WOODEN_STAIRS) || s.is(BlockTags.WOODEN_FENCES)
                || s.is(BlockTags.FENCE_GATES) || s.is(BlockTags.WOODEN_DOORS) || s.is(BlockTags.WOODEN_TRAPDOORS)
                || s.is(BlockTags.WOODEN_BUTTONS) || s.is(BlockTags.WOODEN_PRESSURE_PLATES) || s.is(BlockTags.SAPLINGS)
                || s.is(Blocks.BAMBOO) || s.is(Blocks.BAMBOO_SAPLING) || s.is(Blocks.BAMBOO_BLOCK)
                || s.is(Blocks.STRIPPED_BAMBOO_BLOCK) || s.is(Blocks.BAMBOO_MOSAIC)
                || s.is(Blocks.CRAFTING_TABLE) || s.is(Blocks.CHEST) || s.is(Blocks.TRAPPED_CHEST)
                || s.is(Blocks.BARREL) || s.is(Blocks.BOOKSHELF) || s.is(Blocks.CHISELED_BOOKSHELF)
                || s.is(Blocks.LECTERN) || s.is(Blocks.COMPOSTER) || s.is(Blocks.BEEHIVE) || s.is(Blocks.BEE_NEST)
                || s.is(Blocks.CARTOGRAPHY_TABLE) || s.is(Blocks.FLETCHING_TABLE) || s.is(Blocks.SMITHING_TABLE)
                || s.is(Blocks.LOOM) || s.is(Blocks.MANGROVE_ROOTS) || s.is(Blocks.MUDDY_MANGROVE_ROOTS);
    }

    private void breakBlocks(ServerLevel sl) {
        if (!sl.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return;
        AABB bb = this.getBoundingBox().inflate(1.0, 0.0, 1.0);
        int minX = Mth.floor(bb.minX), maxX = Mth.floor(bb.maxX);
        int minY = Mth.floor(bb.minY), maxY = Mth.floor(bb.maxY);
        int minZ = Mth.floor(bb.minZ), maxZ = Mth.floor(bb.maxZ);
        boolean drops = SirenConfig.BREAK_DROPS.get();
        int budget = 80;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int y = minY; y <= maxY && budget > 0; y++) {
            for (int x = minX; x <= maxX && budget > 0; x++) {
                for (int z = minZ; z <= maxZ && budget > 0; z++) {
                    pos.set(x, y, z);
                    BlockState bs = sl.getBlockState(pos);
                    if (!bs.isAir() && isBreakable(bs)) {
                        sl.destroyBlock(pos, drops, this);
                        budget--;
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ figurehead ring event

    private void tickRing(ServerLevel sl) {
        if (!SirenConfig.RING_ENABLED.get()) return;
        ringTicks++;
        int start = SirenConfig.RING_START_SECONDS.get() * 20;
        int cycle = Math.max(start + 20, SirenConfig.RING_CYCLE_SECONDS.get() * 20);
        if (ringTicks == start) {
            startRing(sl);
        } else if (ringTicks >= cycle) {
            endRing(sl, true);
            ringTicks = 0;
        }
    }

    /** Dipakai juga oleh /sirenhead ring. */
    public void startRing(ServerLevel sl) {
        endRing(sl, false);
        int start = SirenConfig.RING_START_SECONDS.get() * 20;
        int cycle = Math.max(start + 20, SirenConfig.RING_CYCLE_SECONDS.get() * 20);
        int duration = cycle - start;
        spawnRing(sl, this.position(), duration, figureheads);
        AABB near = this.getBoundingBox().inflate(100.0);
        for (SirenHeadEntity s : sl.getEntitiesOfClass(SirenHeadEntity.class, near)) {
            s.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, duration, 254, false, false));
            s.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, 254, false, false));
        }
    }

    /** Memunculkan cincin 10 Figurehead + petir visual + badai. Mengembalikan jumlah yang muncul. */
    public static int spawnRing(ServerLevel sl, Vec3 center, int durationTicks, List<UUID> out) {
        if (SirenConfig.RING_WEATHER.get()) {
            sl.setWeatherParameters(0, durationTicks + 200, true, true);
        }
        int n = 0;
        for (int[] o : RING_OFFSETS) {
            FigureheadEntity f = ModEntities.FIGUREHEAD.get().create(sl);
            if (f == null) continue;
            f.moveTo(center.x + o[0], center.y + 15.0, center.z + o[1], 0.0F, 0.0F);
            f.setMaxLife(durationTicks + 40);
            sl.addFreshEntity(f);
            if (out != null) out.add(f.getUUID());
            n++;
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
            if (bolt != null) {
                bolt.moveTo(f.getX(), center.y, f.getZ());
                bolt.setVisualOnly(true);
                sl.addFreshEntity(bolt);
            }
        }
        return n;
    }

    public void endRing(ServerLevel sl, boolean clearWeather) {
        for (UUID id : figureheads) {
            Entity e = sl.getEntity(id);
            if (e != null) e.discard();
        }
        boolean had = !figureheads.isEmpty();
        figureheads.clear();
        if (had) {
            this.removeEffect(MobEffects.DAMAGE_RESISTANCE);
            this.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        }
        if (clearWeather && SirenConfig.RING_WEATHER.get()) {
            sl.setWeatherParameters(6000, 0, false, false);
        }
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        if (!this.level().isClientSide && reason.shouldDestroy() && this.level() instanceof ServerLevel sl) {
            endRing(sl, !figureheads.isEmpty());
        }
        super.remove(reason);
    }

    // ------------------------------------------------------------------ client events

    @Override
    public void handleEntityEvent(byte id) {
        if (id == EVENT_STOMP) {
            SirenClientHooks.shake(this.position(), 10.0F, 40, 160.0);
        } else if (id == EVENT_EAT) {
            SirenClientHooks.shake(this.position().add(0, 20, 0), 5.0F, 60, 96.0);
        } else {
            super.handleEntityEvent(id);
        }
    }

    // ------------------------------------------------------------------ save

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("RingTicks", ringTicks);
        tag.putInt("IdleTicks", idleTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        ringTicks = tag.getInt("RingTicks");
        idleTicks = tag.getInt("IdleTicks");
        if (this.hasCustomName()) this.bossEvent.setName(this.getDisplayName());
    }

    // ------------------------------------------------------------------ geckolib

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "move", 6, this::moveController)
                .setParticleKeyframeHandler(event -> {
                    var data = event.getKeyframeData();
                    if ("step".equals(data.getEffect())) {
                        SirenClientHooks.footStep(this, "foot_r".equals(data.getLocator()), this.isChasing());
                    }
                }));
        controllers.add(new AnimationController<>(this, "talk", 4,
                state -> isTalking() ? state.setAndContinue(TALK) : PlayState.STOP));
        controllers.add(new AnimationController<>(this, "special", 3, state -> PlayState.STOP)
                .triggerableAnim("stomp", STOMP)
                .triggerableAnim("eat", EAT));
    }

    private PlayState moveController(AnimationState<SirenHeadEntity> state) {
        if (state.isMoving()) {
            return state.setAndContinue(isChasing() ? RUN : WALK);
        }
        return state.setAndContinue(IDLE);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
