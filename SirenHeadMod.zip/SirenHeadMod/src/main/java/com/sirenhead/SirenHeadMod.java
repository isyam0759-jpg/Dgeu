package com.sirenhead;

import com.sirenhead.config.SirenConfig;
import com.sirenhead.registry.ModEffects;
import com.sirenhead.registry.ModEntities;
import com.sirenhead.registry.ModItems;
import com.sirenhead.registry.ModParticles;
import com.sirenhead.registry.ModSounds;
import com.sirenhead.registry.ModTabs;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Port Java Edition (Forge / NeoForge 1.20.1) dari addon Bedrock
 * "Siren Head: The Siren's Field". Hanya untuk pemakaian pribadi.
 */
@Mod(SirenHeadMod.MODID)
public class SirenHeadMod {
    public static final String MODID = "sirenhead";

    public SirenHeadMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModParticles.PARTICLES.register(bus);
        ModEffects.EFFECTS.register(bus);
        ModItems.ITEMS.register(bus);
        ModTabs.TABS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, SirenConfig.SPEC);
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MODID, path);
    }
}
