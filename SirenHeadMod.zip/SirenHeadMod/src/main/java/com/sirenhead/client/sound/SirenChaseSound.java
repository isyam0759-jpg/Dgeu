package com.sirenhead.client.sound;

import com.sirenhead.entity.SirenHeadEntity;
import com.sirenhead.registry.ModSounds;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;

/** Musik kejar yang mengikuti Siren Head selama ia punya target (state "b" controller.animation.controller). */
public class SirenChaseSound extends AbstractTickableSoundInstance {
    private final SirenHeadEntity entity;

    public SirenChaseSound(SirenHeadEntity entity) {
        super(ModSounds.CHASE.get(), SoundSource.HOSTILE, SoundInstance.createUnseededRandom());
        this.entity = entity;
        this.looping = true;
        this.delay = 0;
        this.volume = 10.0F;           // volume > 1 memperluas jangkauan: 16 x 10 = 160 blok
        this.pitch = 1.0F;
        this.attenuation = SoundInstance.Attenuation.LINEAR;
        this.x = entity.getX();
        this.y = entity.getY() + 10.0;
        this.z = entity.getZ();
    }

    @Override
    public void tick() {
        if (entity.isRemoved() || !entity.isAlive() || !entity.isChasing()) {
            this.stop();
            return;
        }
        this.x = entity.getX();
        this.y = entity.getY() + 10.0;
        this.z = entity.getZ();
    }
}
