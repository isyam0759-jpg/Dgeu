package com.sirenhead.client.render;

import com.sirenhead.SirenHeadMod;
import com.sirenhead.entity.FigureheadEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class FigureheadModel extends GeoModel<FigureheadEntity> {
    private static final ResourceLocation MODEL = SirenHeadMod.id("geo/figurehead.geo.json");
    private static final ResourceLocation TEXTURE = SirenHeadMod.id("textures/entity/figurehead.png");
    // bone sirens3/sirens4/head sama namanya dengan model Siren Head, jadi animasinya dipakai bersama
    private static final ResourceLocation ANIMATION = SirenHeadMod.id("animations/sirenhead.animation.json");

    @Override
    public ResourceLocation getModelResource(FigureheadEntity animatable) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(FigureheadEntity animatable) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(FigureheadEntity animatable) {
        return ANIMATION;
    }
}
