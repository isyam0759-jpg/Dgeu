package com.sirenhead.client.render;

import com.sirenhead.SirenHeadMod;
import com.sirenhead.entity.SirenHeadEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class SirenHeadModel extends GeoModel<SirenHeadEntity> {
    private static final ResourceLocation MODEL = SirenHeadMod.id("geo/sirenhead.geo.json");
    private static final ResourceLocation TEXTURE = SirenHeadMod.id("textures/entity/sirenhead.png");
    private static final ResourceLocation ANIMATION = SirenHeadMod.id("animations/sirenhead.animation.json");

    @Override
    public ResourceLocation getModelResource(SirenHeadEntity animatable) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(SirenHeadEntity animatable) {
        return TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(SirenHeadEntity animatable) {
        return ANIMATION;
    }
}
