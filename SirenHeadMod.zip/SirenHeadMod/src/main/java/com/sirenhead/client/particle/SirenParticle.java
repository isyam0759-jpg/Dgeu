package com.sirenhead.client.particle;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Satu kelas partikel serba guna; perilaku tiap jenis ditentukan oleh {@link Spec}.
 * Ukuran = setengah lebar quad (blok).
 */
public class SirenParticle extends TextureSheetParticle {

    public record Spec(int minLife, int maxLife,
                       float size, float growPerSecond,
                       float gravity, float friction, float upBias,
                       boolean flat, boolean stationary, boolean physics, boolean fullbright,
                       int colorStart, int colorEnd, float alphaStart, float alphaEnd) {}

    private final Spec spec;
    private final float scale;

    protected SirenParticle(ClientLevel level, double x, double y, double z,
                            double xd, double yd, double zd, Spec spec, SpriteSet sprites) {
        super(level, x, y, z);
        this.spec = spec;
        this.scale = spec.stationary() && xd > 0.0 ? (float) xd : 1.0F;
        this.lifetime = spec.minLife() + this.random.nextInt(Math.max(1, spec.maxLife() - spec.minLife() + 1));
        this.quadSize = spec.size() * this.scale;
        this.gravity = spec.gravity();
        this.friction = spec.friction();
        this.hasPhysics = spec.physics();
        if (spec.stationary()) {
            this.xd = 0.0;
            this.yd = 0.0;
            this.zd = 0.0;
            double r = (spec.size() + spec.growPerSecond() * (this.lifetime / 20.0)) * this.scale + 1.0;
            this.setBoundingBox(new AABB(x - r, y - 1.0, z - r, x + r, y + r, z + r));
        } else {
            this.xd = xd;
            this.yd = spec.upBias() > 0 ? Math.abs(yd) + spec.upBias() : yd;
            this.zd = zd;
        }
        this.pickSprite(sprites);
        applyLook(0.0F);
    }

    private void applyLook(float t) {
        int c0 = spec.colorStart();
        int c1 = spec.colorEnd();
        this.rCol = Mth.lerp(t, ((c0 >> 16) & 0xFF) / 255.0F, ((c1 >> 16) & 0xFF) / 255.0F);
        this.gCol = Mth.lerp(t, ((c0 >> 8) & 0xFF) / 255.0F, ((c1 >> 8) & 0xFF) / 255.0F);
        this.bCol = Mth.lerp(t, (c0 & 0xFF) / 255.0F, (c1 & 0xFF) / 255.0F);
        this.alpha = Mth.clamp(Mth.lerp(t, spec.alphaStart(), spec.alphaEnd()), 0.0F, 1.0F);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        if (!spec.stationary()) {
            this.yd -= 0.04 * this.gravity;
            this.move(this.xd, this.yd, this.zd);
            this.xd *= this.friction;
            this.yd *= this.friction;
            this.zd *= this.friction;
            if (this.onGround) {
                this.xd *= 0.7;
                this.zd *= 0.7;
            }
        }
        applyLook((float) this.age / (float) this.lifetime);
    }

    @Override
    public float getQuadSize(float partialTick) {
        return (spec.size() + spec.growPerSecond() * ((this.age + partialTick) / 20.0F)) * this.scale;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return spec.fullbright() ? 15728880 : super.getLightColor(partialTick);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public void render(VertexConsumer buffer, Camera camera, float partialTick) {
        if (!spec.flat()) {
            super.render(buffer, camera, partialTick);
            return;
        }
        // cincin datar menghadap atas (emitter_transform_xz di Bedrock)
        Vec3 cam = camera.getPosition();
        float px = (float) (Mth.lerp(partialTick, this.xo, this.x) - cam.x());
        float py = (float) (Mth.lerp(partialTick, this.yo, this.y) - cam.y()) + 0.05F;
        float pz = (float) (Mth.lerp(partialTick, this.zo, this.z) - cam.z());
        float s = getQuadSize(partialTick);
        float u0 = getU0();
        float u1 = getU1();
        float v0 = getV0();
        float v1 = getV1();
        int light = getLightColor(partialTick);

        vertex(buffer, px - s, py, pz - s, u1, v1, light);
        vertex(buffer, px - s, py, pz + s, u1, v0, light);
        vertex(buffer, px + s, py, pz + s, u0, v0, light);
        vertex(buffer, px + s, py, pz - s, u0, v1, light);
        // sisi bawah
        vertex(buffer, px + s, py, pz - s, u0, v1, light);
        vertex(buffer, px + s, py, pz + s, u0, v0, light);
        vertex(buffer, px - s, py, pz + s, u1, v0, light);
        vertex(buffer, px - s, py, pz - s, u1, v1, light);
    }

    private void vertex(VertexConsumer b, float x, float y, float z, float u, float v, int light) {
        b.vertex(x, y, z).uv(u, v).color(this.rCol, this.gCol, this.bCol, this.alpha).uv2(light).endVertex();
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final Spec spec;

        public Provider(SpriteSet sprites, Spec spec) {
            this.sprites = sprites;
            this.spec = spec;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xd, double yd, double zd) {
            return new SirenParticle(level, x, y, z, xd, yd, zd, spec, sprites);
        }
    }
}
