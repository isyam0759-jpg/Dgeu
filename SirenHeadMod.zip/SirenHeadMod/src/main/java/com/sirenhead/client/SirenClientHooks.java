package com.sirenhead.client;

import com.sirenhead.client.sound.SirenChaseSound;
import com.sirenhead.config.SirenConfig;
import com.sirenhead.entity.SirenHeadEntity;
import com.sirenhead.registry.ModSounds;
import com.sirenhead.registry.ModParticles;
import com.sirenhead.util.SirenFx;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;

/** Dipanggil dari kode entity hanya saat level.isClientSide, jadi aman di dedicated server. */
public final class SirenClientHooks {
    private static final Map<Integer, SirenChaseSound> CHASE = new HashMap<>();
    private static final Map<Integer, Long> LAST_START = new HashMap<>();

    public static void tickSiren(SirenHeadEntity e) {
        if (!SirenConfig.CHASE_MUSIC.get() || !e.isChasing()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.distanceToSqr(e) > 160.0 * 160.0) return;
        SirenChaseSound s = CHASE.get(e.getId());
        boolean playing = s != null && !s.isStopped() && mc.getSoundManager().isActive(s);
        if (playing) return;
        long now = e.level().getGameTime();
        Long last = LAST_START.get(e.getId());
        if (last != null && now - last < 20L) return;      // jangan membanjiri engine suara
        s = new SirenChaseSound(e);
        CHASE.put(e.getId(), s);
        LAST_START.put(e.getId(), now);
        mc.getSoundManager().play(s);
    }

    /**
     * Dipanggil keyframe "step" di animasi jalan/lari, tepat saat telapak kaki menyentuh tanah.
     * Jalan: tiap 1,6 dtk; lari: tiap ~0,48 dtk (sama seperti animation.walk / run addon asli).
     */
    public static void footStep(SirenHeadEntity e, boolean right, boolean running) {
        Level level = e.level();
        Vec3 p = SirenFx.footPos(e, right);
        RandomSource r = e.getRandom();
        level.playLocalSound(p.x, p.y, p.z, ModSounds.STEP.get(), SoundSource.HOSTILE,
                8.0F, 0.9F + r.nextFloat() * 0.2F, false);
        shake(p, 4.0F, running ? 6 : 10, 96.0);
        if (!SirenConfig.EXTRA_PARTICLES.get()) return;

        double scale = running ? 0.32 : 0.22;
        level.addParticle(ModParticles.SHOCKWAVE.get(), p.x, p.y + 0.05, p.z, scale, 0.0, 0.0);

        int n = running ? 14 : 9;
        for (int i = 0; i < n; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0;
            double sp = 0.12 + r.nextDouble() * 0.25;
            double vx = Math.cos(ang) * sp;
            double vz = Math.sin(ang) * sp;
            double dist = 0.6 + r.nextDouble() * 1.8;
            double ox = Math.cos(ang) * dist;
            double oz = Math.sin(ang) * dist;
            level.addParticle(ModParticles.DUST_CLOUD.get(), p.x + ox, p.y + 0.2, p.z + oz,
                    vx, 0.03 + r.nextDouble() * 0.05, vz);
            if ((i & 1) == 0) {
                level.addParticle(ModParticles.DEBRIS.get(), p.x + ox, p.y + 0.3, p.z + oz,
                        vx * 2.0, 0.2 + r.nextDouble() * 0.3, vz * 2.0);
            }
        }
        BlockState below = level.getBlockState(BlockPos.containing(p.x, p.y - 0.3, p.z));
        if (!below.isAir()) {
            BlockParticleOption opt = new BlockParticleOption(ParticleTypes.BLOCK, below);
            for (int i = 0; i < 14; i++) {
                double ang = r.nextDouble() * Math.PI * 2.0;
                double sp = 0.1 + r.nextDouble() * 0.3;
                level.addParticle(opt, p.x + Math.cos(ang) * 1.2, p.y + 0.2, p.z + Math.sin(ang) * 1.2,
                        Math.cos(ang) * sp, 0.2 + r.nextDouble() * 0.35, Math.sin(ang) * sp);
            }
        }
    }

    public static void shake(Vec3 pos, float intensity, int ticks, double radius) {
        CameraShake.add(null, pos, intensity * SirenConfig.SHAKE_STRENGTH.get().floatValue(), ticks, radius);
    }

    private SirenClientHooks() {}
}
