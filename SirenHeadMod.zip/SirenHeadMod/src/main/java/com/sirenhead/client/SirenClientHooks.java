package com.sirenhead.client;

import com.sirenhead.client.sound.SirenChaseSound;
import com.sirenhead.config.SirenConfig;
import com.sirenhead.entity.SirenHeadEntity;
import com.sirenhead.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;

/** Dipanggil dari kode entity hanya saat level.isClientSide, jadi aman di dedicated server. */
public final class SirenClientHooks {
    private static final Map<Integer, SirenChaseSound> CHASE = new HashMap<>();
    private static final Map<Integer, Long> LAST_START = new HashMap<>();

    public static void tickSiren(SirenHeadEntity e) {
        if (!SirenConfig.CHASE_MUSIC.get() || !e.isChasing()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.distanceToSqr(e) > 160.0 * 160.0) return;
        SirenChaseSound s = CHASE.get(e.getId());
        boolean playing = s != null && !s.isStopped() && mc.getSoundManager().isActive(s);
        if (playing) return;
        long now = e.level().getGameTime();
        Long last = LAST_START.get(e.getId());
        if (last != null && now - last < 20L) return;      // jangan membanjiri engine suara
        s = new SirenChaseSound(e);
        CHASE.put(e.getId(), s);
        LAST_START.put(e.getId(), now);
        mc.getSoundManager().play(s);
    }

    /** Langkah kaki: suara + getaran. Berjalan: tiap 1,6 dtk; berlari: tiap 0,5 dtk (seperti animation.walk / run). */
    public static void step(SirenHeadEntity e, boolean running) {
        float pitch = 0.9F + e.getRandom().nextFloat() * 0.2F;
        e.level().playLocalSound(e.getX(), e.getY(), e.getZ(), ModSounds.STEP.get(), SoundSource.HOSTILE,
                8.0F, pitch, false);
        shake(e.position(), 4.0F, running ? 6 : 10, 96.0);
    }

    public static void shake(Vec3 pos, float intensity, int ticks, double radius) {
        CameraShake.add(null, pos, intensity * SirenConfig.SHAKE_STRENGTH.get().floatValue(), ticks, radius);
    }

    private SirenClientHooks() {}
}
