package com.sirenhead.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.sirenhead.SirenHeadMod;
import com.sirenhead.entity.FigureheadEntity;
import com.sirenhead.entity.SirenHeadEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Comparator;
import java.util.List;

/**
 * /sirenhead ring   - panggil cincin Figurehead di posisimu
 * /sirenhead clear  - hapus semua Figurehead yang termuat
 * /sirenhead stomp  - paksa Siren Head terdekat menghentak
 * /sirenhead eat    - paksa Siren Head terdekat menerkammu
 */
@Mod.EventBusSubscriber(modid = SirenHeadMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class SirenCommands {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("sirenhead")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("ring").executes(SirenCommands::ring))
                .then(Commands.literal("clear").executes(SirenCommands::clear))
                .then(Commands.literal("stomp").executes(SirenCommands::stomp))
                .then(Commands.literal("eat").executes(SirenCommands::eat)));
    }

    private static int ring(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        SirenHeadEntity.spawnRing(src.getLevel(), src.getPosition(), 1200, null);
        src.sendSuccess(() -> Component.translatable("commands.sirenhead.ring"), true);
        return 1;
    }

    private static int clear(CommandContext<CommandSourceStack> ctx) {
        ServerLevel level = ctx.getSource().getLevel();
        int n = 0;
        for (var e : level.getAllEntities()) {
            if (e instanceof FigureheadEntity f) {
                f.discard();
                n++;
            }
        }
        final int count = n;
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.sirenhead.clear", count), true);
        return n;
    }

    private static SirenHeadEntity nearest(CommandSourceStack src) {
        Vec3 p = src.getPosition();
        List<SirenHeadEntity> list = src.getLevel().getEntitiesOfClass(SirenHeadEntity.class,
                new AABB(p, p).inflate(300.0));
        return list.stream().min(Comparator.comparingDouble(s -> s.distanceToSqr(p))).orElse(null);
    }

    private static int stomp(CommandContext<CommandSourceStack> ctx) {
        SirenHeadEntity s = nearest(ctx.getSource());
        if (s == null) {
            ctx.getSource().sendFailure(Component.translatable("commands.sirenhead.none"));
            return 0;
        }
        s.startStomp(ctx.getSource().getLevel());
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.sirenhead.stomp"), true);
        return 1;
    }

    private static int eat(CommandContext<CommandSourceStack> ctx) {
        SirenHeadEntity s = nearest(ctx.getSource());
        if (s == null) {
            ctx.getSource().sendFailure(Component.translatable("commands.sirenhead.none"));
            return 0;
        }
        LivingEntity victim = ctx.getSource().getEntity() instanceof ServerPlayer sp ? sp : s.getTarget();
        if (victim == null) {
            ctx.getSource().sendFailure(Component.translatable("commands.sirenhead.none"));
            return 0;
        }
        s.startEat(ctx.getSource().getLevel(), victim);
        ctx.getSource().sendSuccess(() -> Component.translatable("commands.sirenhead.eat"), true);
        return 1;
    }

    private SirenCommands() {}
}
