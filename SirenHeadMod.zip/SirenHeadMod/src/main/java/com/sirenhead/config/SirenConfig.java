package com.sirenhead.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Semua angka default = nilai asli addon Bedrock. Ubah di config/sirenhead-common.toml. */
public final class SirenConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.DoubleValue EFFECTIVE_HEALTH;
    public static final ForgeConfigSpec.DoubleValue ATTACK_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue MOVE_SPEED;
    public static final ForgeConfigSpec.DoubleValue FOLLOW_RANGE;
    public static final ForgeConfigSpec.IntValue ATTACK_COOLDOWN_TICKS;
    public static final ForgeConfigSpec.BooleanValue BREAK_BLOCKS;
    public static final ForgeConfigSpec.BooleanValue BREAK_DROPS;
    public static final ForgeConfigSpec.BooleanValue NATURAL_SPAWN;
    public static final ForgeConfigSpec.BooleanValue BOSS_BAR;

    public static final ForgeConfigSpec.IntValue SPECIAL_INTERVAL_TICKS;
    public static final ForgeConfigSpec.DoubleValue STOMP_RADIUS;
    public static final ForgeConfigSpec.DoubleValue STOMP_FLAT_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue STOMP_PERCENT_DAMAGE;
    public static final ForgeConfigSpec.BooleanValue STOMP_HITS_ALL_MOBS;
    public static final ForgeConfigSpec.DoubleValue EAT_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue EAT_HEAL;

    public static final ForgeConfigSpec.BooleanValue RING_ENABLED;
    public static final ForgeConfigSpec.BooleanValue RING_WEATHER;
    public static final ForgeConfigSpec.IntValue RING_START_SECONDS;
    public static final ForgeConfigSpec.IntValue RING_CYCLE_SECONDS;
    public static final ForgeConfigSpec.DoubleValue FIGUREHEAD_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue FIGUREHEAD_RADIUS;

    public static final ForgeConfigSpec.BooleanValue CHASE_MUSIC;
    public static final ForgeConfigSpec.DoubleValue SHAKE_STRENGTH;
    public static final ForgeConfigSpec.BooleanValue EXTRA_PARTICLES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("Siren Head").push("siren_head");
        EFFECTIVE_HEALTH = b.comment("HP efektif. Atribut max health Java dibatasi 1024, jadi damage diskalakan agar setara HP ini. Asli: 80000")
                .defineInRange("effectiveHealth", 80000.0, 1024.0, 10_000_000.0);
        ATTACK_DAMAGE = b.defineInRange("attackDamage", 6.0, 0.0, 10_000.0);
        MOVE_SPEED = b.comment("Atribut kecepatan Java (zombie = 0.23). Addon asli memakai 0.5 yang di Java terasa terlalu cepat.")
                .defineInRange("movementSpeed", 0.42, 0.05, 2.0);
        FOLLOW_RANGE = b.defineInRange("followRange", 100.0, 16.0, 2048.0);
        ATTACK_COOLDOWN_TICKS = b.comment("Asli: 6 detik").defineInRange("attackCooldownTicks", 120, 5, 6000);
        BREAK_BLOCKS = b.comment("Menghancurkan kayu/daun/dll di sekitarnya (butuh gamerule mobGriefing)").define("breakBlocks", true);
        BREAK_DROPS = b.define("breakBlocksDropItems", false);
        NATURAL_SPAWN = b.comment("Spawn alami di Overworld (permukaan, gelap). Telur spawn & /summon selalu bisa.").define("naturalSpawn", true);
        BOSS_BAR = b.define("bossBar", true);
        b.pop();

        b.comment("Serangan spesial (hentak & terkam)").push("special_attacks");
        SPECIAL_INTERVAL_TICKS = b.comment("Tick dekat target sebelum serangan spesial. Asli: 100").defineInRange("intervalTicks", 100, 20, 24000);
        STOMP_RADIUS = b.comment("Asli: 50").defineInRange("stompRadius", 50.0, 1.0, 512.0);
        STOMP_FLAT_DAMAGE = b.comment("Asli: 700").defineInRange("stompFlatDamage", 700.0, 0.0, 100000.0);
        STOMP_PERCENT_DAMAGE = b.comment("Damage tambahan = max HP korban x nilai ini. Asli: 0.03").defineInRange("stompPercentDamage", 0.03, 0.0, 10.0);
        STOMP_HITS_ALL_MOBS = b.comment("false = hanya pemain").define("stompHitsAllMobs", true);
        EAT_DAMAGE = b.comment("Asli: 1800").defineInRange("eatDamage", 1800.0, 0.0, 100000.0);
        EAT_HEAL = b.comment("HP efektif yang dipulihkan setelah menerkam").defineInRange("eatHeal", 1000.0, 0.0, 1_000_000.0);
        b.pop();

        b.comment("Event cincin Figurehead").push("figurehead_ring");
        RING_ENABLED = b.define("enabled", true);
        RING_WEATHER = b.comment("Badai petir selama event").define("changeWeather", true);
        RING_START_SECONDS = b.comment("Asli: 80").defineInRange("startSeconds", 80, 1, 100000);
        RING_CYCLE_SECONDS = b.comment("Asli: 140").defineInRange("cycleSeconds", 140, 2, 100000);
        FIGUREHEAD_DAMAGE = b.comment("Asli: 50 tiap 2 detik").defineInRange("pulseDamage", 50.0, 0.0, 100000.0);
        FIGUREHEAD_RADIUS = b.comment("Asli: 30").defineInRange("pulseRadius", 30.0, 1.0, 256.0);
        b.pop();

        b.comment("Klien").push("client");
        CHASE_MUSIC = b.define("chaseMusic", true);
        SHAKE_STRENGTH = b.comment("Pengali getaran kamera. 0 = mati").defineInRange("cameraShake", 1.0, 0.0, 5.0);
        EXTRA_PARTICLES = b.comment("Partikel debu & puing saat berjalan").define("walkParticles", true);
        b.pop();

        SPEC = b.build();
    }

    private SirenConfig() {}
}
