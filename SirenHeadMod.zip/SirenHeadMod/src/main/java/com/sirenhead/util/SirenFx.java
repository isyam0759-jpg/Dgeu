package com.sirenhead.util;

import com.sirenhead.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/** Efek partikel sisi server (dikirim ke semua pemain dalam jangkauan, melewati batas 32 blok vanilla). */
public final class SirenFx {

    public static void send(ServerLevel level, ParticleOptions options, double x, double y, double z,
                            int count, double dx, double dy, double dz, double speed, double range) {
        double r2 = range * range;
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(x, y, z) <= r2) {
                level.sendParticles(player, options, true, x, y, z, count, dx, dy, dz, speed);
            }
        }
    }

    /** Hentakan: cincin kejut, awan debu, puing, gelombang suara, serpihan blok. */
    public static void stomp(ServerLevel level, Vec3 p) {
        double range = 320;
        send(level, ModParticles.SHOCKWAVE.get(), p.x, p.y + 0.1, p.z, 1, 0, 0, 0, 0, range);
        send(level, ModParticles.SOUND_WAVE.get(), p.x, p.y + 0.5, p.z, 1, 0, 0, 0, 0, range);
        send(level, ModParticles.DUST_CLOUD.get(), p.x, p.y + 0.4, p.z, 90, 7.0, 0.4, 7.0, 0.12, range);
        send(level, ModParticles.DEBRIS.get(), p.x, p.y + 0.6, p.z, 160, 5.0, 0.3, 5.0, 0.55, range);
        BlockPos below = BlockPos.containing(p).below();
        send(level, new BlockParticleOption(ParticleTypes.BLOCK, level.getBlockState(below)),
                p.x, p.y + 0.5, p.z, 200, 9.0, 0.3, 9.0, 0.45, range);
        send(level, ParticleTypes.EXPLOSION_EMITTER, p.x, p.y + 1.0, p.z, 1, 0, 0, 0, 0, range);
    }

    /** Darah saat korban dimakan. */
    public static void blood(ServerLevel level, Vec3 p) {
        send(level, ModParticles.BLOOD_SPLAT.get(), p.x, p.y, p.z, 1, 0, 0, 0, 0, 200);
        send(level, ModParticles.BLOOD_DROP.get(), p.x, p.y, p.z, 60, 0.5, 0.5, 0.5, 0.35, 200);
    }

    /** Denyut jeritan Figurehead. */
    public static void pulse(ServerLevel level, Vec3 p) {
        send(level, ModParticles.SOUND_WAVE.get(), p.x, p.y, p.z, 1, 0, 0, 0, 0, 300);
        send(level, ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0, 0, 0, 0, 300);
    }

    private SirenFx() {}
}
