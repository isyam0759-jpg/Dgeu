package com.sirenhead.registry;

import com.sirenhead.SirenHeadMod;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SirenHeadMod.MODID);

    public static final RegistryObject<SoundEvent> ALARM = reg("alarm");
    public static final RegistryObject<SoundEvent> CHASE = reg("chase");
    public static final RegistryObject<SoundEvent> STOMP = reg("stomp");
    public static final RegistryObject<SoundEvent> STEP = reg("step");
    public static final RegistryObject<SoundEvent> DEAD = reg("dead");
    public static final RegistryObject<SoundEvent> SCREAM = reg("scream");
    public static final RegistryObject<SoundEvent> JUMPSCARE = reg("jumpscare");
    public static final RegistryObject<SoundEvent> COOL = reg("cool");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(SirenHeadMod.id(name)));
    }

    private ModSounds() {}
}
