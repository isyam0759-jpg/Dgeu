package com.sirenhead.registry;

import com.sirenhead.SirenHeadMod;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SirenHeadMod.MODID);

    /** 17 klip alarm terpisah agar durasinya diketahui (animasi bicara berhenti saat klip habis). */
    public static final List<RegistryObject<SoundEvent>> ALARMS = new ArrayList<>();
    public static final RegistryObject<SoundEvent> CHASE = reg("chase");
    public static final RegistryObject<SoundEvent> STOMP = reg("stomp");
    public static final RegistryObject<SoundEvent> STEP = reg("step");
    public static final RegistryObject<SoundEvent> DEAD = reg("dead");
    public static final RegistryObject<SoundEvent> SCREAM = reg("scream");
    public static final RegistryObject<SoundEvent> JUMPSCARE = reg("jumpscare");
    public static final RegistryObject<SoundEvent> COOL = reg("cool");

    static {
        for (int i = 0; i < 17; i++) ALARMS.add(reg("alarm_" + i));
    }

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(SirenHeadMod.id(name)));
    }

    private ModSounds() {}
}
