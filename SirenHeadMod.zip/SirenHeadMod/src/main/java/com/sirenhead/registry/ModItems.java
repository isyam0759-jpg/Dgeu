package com.sirenhead.registry;

import com.sirenhead.SirenHeadMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SirenHeadMod.MODID);

    public static final RegistryObject<Item> SIREN_HEAD_SPAWN_EGG = ITEMS.register("siren_head_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SIREN_HEAD, 0x0B0A0A, 0x171515, new Item.Properties()));

    private ModItems() {}
}
