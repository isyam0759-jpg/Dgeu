package com.sirenhead.registry;

import com.sirenhead.SirenHeadMod;
import com.sirenhead.effect.SirenMobEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, SirenHeadMod.MODID);

    /** Teror: lambat, lemah, jantung berdetak keras. */
    public static final RegistryObject<MobEffect> TERROR = EFFECTS.register("terror", () ->
            new SirenMobEffect(MobEffectCategory.HARMFUL, 0x3A0D0D)
                    .addAttributeModifier(Attributes.MOVEMENT_SPEED, "5b3f7f9e-8e1c-4b7a-9d2f-1a6c0e4d7a11",
                            -0.20, AttributeModifier.Operation.MULTIPLY_TOTAL)
                    .addAttributeModifier(Attributes.ATTACK_DAMAGE, "c2d8a6b4-3f0e-4c59-8a71-6e9b2d5f1c22",
                            -2.0, AttributeModifier.Operation.ADDITION));

    /** Tuli sementara: telinga berdenging dan layar bergetar. */
    public static final RegistryObject<MobEffect> DEAFENED = EFFECTS.register("deafened", () ->
            new SirenMobEffect(MobEffectCategory.HARMFUL, 0x8A8FA8));

    private ModEffects() {}
}
