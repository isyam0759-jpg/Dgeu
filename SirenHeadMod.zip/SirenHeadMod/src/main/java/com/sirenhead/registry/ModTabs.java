package com.sirenhead.registry;

import com.sirenhead.SirenHeadMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SirenHeadMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.sirenhead"))
                    .icon(() -> new ItemStack(ModItems.SIREN_HEAD_SPAWN_EGG.get()))
                    .displayItems((params, output) -> output.accept(ModItems.SIREN_HEAD_SPAWN_EGG.get()))
                    .build());

    private ModTabs() {}
}
