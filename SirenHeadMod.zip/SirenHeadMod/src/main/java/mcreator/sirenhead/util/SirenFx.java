package mcreator.sirenhead.util;

import mcreator.sirenhead.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** Efek partikel sisi server (dikirim ke semua pemain dalam jangkauan, melewati batas 32 blok vanilla). */
public final class SirenFx {

    public static void send(ServerLevel level, ParticleOptions options, double x, double y, double z,
                            int count, double dx, double dy, double dz, double speed, double range) {
        double r2 = range * range;
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(x, y, z) <= r2) {
                level.sendParticles(player, options, true, x, y, z, count, dx, dy, dz, speed);
            }
        }
    }

    /**
     * Posisi telapak kaki di tanah (dari pusat geometri kaki model: x = +-0.67 blok, 0.9 blok di depan).
     * right = kaki bone6 (sisi +x model = kanan mob).
     */
    public static Vec3 footPos(LivingEntity e, boolean right) {
        double yaw = Math.toRadians(e.yBodyRot);
        double fx = -Math.sin(yaw);
        double fz = Math.cos(yaw);
        double rx = -Math.cos(yaw);
        double rz = -Math.sin(yaw);
        double side = right ? 0.67 : -0.67;
        double fwd = 0.9;
        return new Vec3(e.getX() + rx * side + fx * fwd, e.getY(), e.getZ() + rz * side + fz * fwd);
    }

    /** Cincin datar: count=0 dan dx = skala (1.0 = radius ~17 blok). */
    public static void ring(ServerLevel level, net.minecraft.core.particles.SimpleParticleType type,
                            double x, double y, double z, double scale, double range) {
        send(level, type, x, y, z, 0, scale, 0, 0, 1.0, range);
    }

    /** Hentakan di telapak kaki yang menghantam: cincin kejut, awan debu, puing, gelombang suara, serpihan blok. */
    public static void stomp(ServerLevel level, Vec3 p) {
        double range = 320;
        ring(level, ModParticles.SHOCKWAVE.get(), p.x, p.y + 0.1, p.z, 1.0, range);
        ring(level, ModParticles.SHOCKWAVE.get(), p.x, p.y + 0.2, p.z, 0.55, range);
        ring(level, ModParticles.SOUND_WAVE.get(), p.x, p.y + 0.5, p.z, 0.5, range);
        send(level, ModParticles.DUST_CLOUD.get(), p.x, p.y + 0.4, p.z, 120, 5.0, 0.4, 5.0, 0.16, range);
        send(level, ModParticles.DEBRIS.get(), p.x, p.y + 0.6, p.z, 180, 3.5, 0.3, 3.5, 0.6, range);
        BlockPos below = BlockPos.containing(p.x, p.y - 0.3, p.z);
        if (!level.getBlockState(below).isAir()) {
            send(level, new BlockParticleOption(ParticleTypes.BLOCK, level.getBlockState(below)),
                    p.x, p.y + 0.5, p.z, 220, 6.0, 0.3, 6.0, 0.5, range);
        }
        send(level, ParticleTypes.EXPLOSION_EMITTER, p.x, p.y + 0.8, p.z, 1, 0, 0, 0, 0, range);
    }

    /** Darah saat korban dimakan. */
    public static void blood(ServerLevel level, Vec3 p) {
        send(level, ModParticles.BLOOD_SPLAT.get(), p.x, p.y, p.z, 1, 0, 0, 0, 0, 200);
        send(level, ModParticles.BLOOD_DROP.get(), p.x, p.y, p.z, 60, 0.5, 0.5, 0.5, 0.35, 200);
    }

    /** Denyut jeritan Figurehead: cincin di dasar tiang yang mengembang sampai radius damage. */
    public static void pulse(ServerLevel level, Vec3 base, double radius) {
        double scale = radius / 17.5;
        ring(level, ModParticles.SHOCKWAVE.get(), base.x, base.y + 0.1, base.z, scale, 300);
        ring(level, ModParticles.SOUND_WAVE.get(), base.x, base.y + 0.6, base.z, 0.4, 300);
        send(level, ModParticles.DUST_CLOUD.get(), base.x, base.y + 0.3, base.z, 25, 2.0, 0.2, 2.0, 0.1, 300);
    }

    private SirenFx() {}
}
