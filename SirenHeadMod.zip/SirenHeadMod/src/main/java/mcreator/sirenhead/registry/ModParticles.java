package mcreator.sirenhead.registry;

import mcreator.sirenhead.SirenHeadMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, SirenHeadMod.MODID);

    /** Cincin kejut datar di tanah (shockwave:particle). */
    public static final RegistryObject<SimpleParticleType> SHOCKWAVE = reg("shockwave");
    /** Gelombang suara membesar (sound:particle, sh:shockwave). */
    public static final RegistryObject<SimpleParticleType> SOUND_WAVE = reg("sound_wave");
    /** Awan debu (dust:particle, sh:dust1). */
    public static final RegistryObject<SimpleParticleType> DUST_CLOUD = reg("dust_cloud");
    /** Puing beterbangan (dirt:particle, diddy:particle). */
    public static final RegistryObject<SimpleParticleType> DEBRIS = reg("debris");
    /** Cipratan darah (blood:particle). */
    public static final RegistryObject<SimpleParticleType> BLOOD_SPLAT = reg("blood_splat");
    /** Tetesan darah jatuh (sh:siren_blood). */
    public static final RegistryObject<SimpleParticleType> BLOOD_DROP = reg("blood_drop");

    private static RegistryObject<SimpleParticleType> reg(String name) {
        return PARTICLES.register(name, () -> new SimpleParticleType(true));
    }

    private ModParticles() {}
}
