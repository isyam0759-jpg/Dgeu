package mcreator.sirenhead.registry;

import mcreator.sirenhead.SirenHeadMod;
import mcreator.sirenhead.entity.FigureheadEntity;
import mcreator.sirenhead.entity.SirenHeadEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SirenHeadMod.MODID);

    /** Hitbox asli addon: 2 x 25 blok. */
    public static final RegistryObject<EntityType<SirenHeadEntity>> SIREN_HEAD = ENTITIES.register("siren_head",
            () -> EntityType.Builder.of(SirenHeadEntity::new, MobCategory.MONSTER)
                    .sized(2.0F, 25.0F)
                    .clientTrackingRange(16)
                    .updateInterval(2)
                    .build("siren_head"));

    /** Hitbox asli addon: 0.6 x 15 blok. */
    public static final RegistryObject<EntityType<FigureheadEntity>> FIGUREHEAD = ENTITIES.register("figurehead",
            () -> EntityType.Builder.of(FigureheadEntity::new, MobCategory.MISC)
                    .sized(0.6F, 15.0F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(3)
                    .build("figurehead"));

    private ModEntities() {}
}
