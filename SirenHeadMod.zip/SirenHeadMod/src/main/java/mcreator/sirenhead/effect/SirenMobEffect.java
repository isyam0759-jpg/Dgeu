package mcreator.sirenhead.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Efek sederhana; perilaku visual/suara ada di ClientEvents. */
public class SirenMobEffect extends MobEffect {
    public SirenMobEffect(MobEffectCategory category, int color) {
        super(category, color);
    }
}
