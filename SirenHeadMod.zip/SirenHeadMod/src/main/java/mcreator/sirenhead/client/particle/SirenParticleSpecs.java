package mcreator.sirenhead.client.particle;

import mcreator.sirenhead.client.particle.SirenParticle.Spec;

/** Padanan Java untuk file particles/*.json Bedrock. */
public final class SirenParticleSpecs {

    //                                      life     size  grow  grav  fric  upB  flat   stat   phys   full   color0    color1    a0    a1
    /** shockwave.particle.json: cincin datar 1,5 dtk, membesar ~70 blok/dtk, memudar. */
    public static final Spec SHOCKWAVE   = new Spec(30, 30, 0.5F, 35.0F, 0.0F, 1.00F, 0.0F, true,  true,  false, true,  0xFFFFFF, 0xFFFFFF, 1.0F, 0.0F);
    /** sound.json / much_more_shockwave: gelombang suara membesar cepat. */
    public static final Spec SOUND_WAVE  = new Spec(20, 20, 0.5F, 25.0F, 0.0F, 1.00F, 0.0F, false, true,  false, true,  0xFFFFFF, 0xFFFFFF, 1.0F, 0.0F);
    /** dust.particle.json / dust1: awan debu coklat-abu naik perlahan. */
    public static final Spec DUST_CLOUD  = new Spec(30, 50, 1.6F,  4.0F, -0.015F, 0.92F, 0.0F, false, false, false, false, 0x9A8D7B, 0x6B6155, 0.75F, 0.0F);
    /** dirt.particle.json / diddy: puing jatuh dan memantul. */
    public static final Spec DEBRIS      = new Spec(60, 110, 0.25F, 0.0F, 1.00F, 0.98F, 0.35F, false, false, true,  false, 0x8C7A66, 0x5B4E40, 1.0F, 0.3F);
    /** blood.json: cipratan membesar lalu memudar ke merah tua. */
    public static final Spec BLOOD_SPLAT = new Spec(10, 10, 0.5F, 15.0F, 0.0F, 1.00F, 0.0F, false, true,  false, false, 0xFFFFFF, 0x4A1414, 1.0F, 0.2F);
    /** siren_blood.json: tetesan merah jatuh. */
    public static final Spec BLOOD_DROP  = new Spec(100, 200, 0.12F, 0.0F, 0.60F, 0.99F, 0.0F, false, false, true,  false, 0x750000, 0x5D1313, 1.0F, 0.0F);

    private SirenParticleSpecs() {}
}
