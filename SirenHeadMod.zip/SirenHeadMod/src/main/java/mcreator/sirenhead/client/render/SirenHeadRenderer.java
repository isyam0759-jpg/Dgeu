package mcreator.sirenhead.client.render;

import mcreator.sirenhead.entity.SirenHeadEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class SirenHeadRenderer extends GeoEntityRenderer<SirenHeadEntity> {
    public SirenHeadRenderer(EntityRendererProvider.Context context) {
        super(context, new SirenHeadModel());
        this.shadowRadius = 4.0F;
    }
}
