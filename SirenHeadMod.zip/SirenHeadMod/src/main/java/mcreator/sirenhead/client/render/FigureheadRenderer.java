package mcreator.sirenhead.client.render;

import mcreator.sirenhead.entity.FigureheadEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class FigureheadRenderer extends GeoEntityRenderer<FigureheadEntity> {
    public FigureheadRenderer(EntityRendererProvider.Context context) {
        super(context, new FigureheadModel());
        this.shadowRadius = 0.6F;
    }
}
