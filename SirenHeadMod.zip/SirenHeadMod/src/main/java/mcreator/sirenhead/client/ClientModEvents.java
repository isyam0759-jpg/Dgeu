package mcreator.sirenhead.client;

import mcreator.sirenhead.SirenHeadMod;
import mcreator.sirenhead.client.particle.SirenParticle;
import mcreator.sirenhead.client.particle.SirenParticleSpecs;
import mcreator.sirenhead.client.render.FigureheadRenderer;
import mcreator.sirenhead.client.render.SirenHeadRenderer;
import mcreator.sirenhead.registry.ModEntities;
import mcreator.sirenhead.registry.ModParticles;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SirenHeadMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientModEvents {

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.SIREN_HEAD.get(), SirenHeadRenderer::new);
        event.registerEntityRenderer(ModEntities.FIGUREHEAD.get(), FigureheadRenderer::new);
    }

    @SubscribeEvent
    public static void particles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.SHOCKWAVE.get(), s -> new SirenParticle.Provider(s, SirenParticleSpecs.SHOCKWAVE));
        event.registerSpriteSet(ModParticles.SOUND_WAVE.get(), s -> new SirenParticle.Provider(s, SirenParticleSpecs.SOUND_WAVE));
        event.registerSpriteSet(ModParticles.DUST_CLOUD.get(), s -> new SirenParticle.Provider(s, SirenParticleSpecs.DUST_CLOUD));
        event.registerSpriteSet(ModParticles.DEBRIS.get(), s -> new SirenParticle.Provider(s, SirenParticleSpecs.DEBRIS));
        event.registerSpriteSet(ModParticles.BLOOD_SPLAT.get(), s -> new SirenParticle.Provider(s, SirenParticleSpecs.BLOOD_SPLAT));
        event.registerSpriteSet(ModParticles.BLOOD_DROP.get(), s -> new SirenParticle.Provider(s, SirenParticleSpecs.BLOOD_DROP));
    }

    private ClientModEvents() {}
}
