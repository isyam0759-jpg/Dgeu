package mcreator.sirenhead.client;

import mcreator.sirenhead.SirenHeadMod;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Pengganti /camerashake Bedrock: getaran posisional yang melemah menurut jarak dan waktu. */
@Mod.EventBusSubscriber(modid = SirenHeadMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CameraShake {
    private static final class Shake {
        String tag;
        Vec3 pos;
        float intensity;
        int duration;
        int age;
        double radius;
    }

    private static final List<Shake> SHAKES = new ArrayList<>();

    public static void add(String tag, Vec3 pos, float intensity, int durationTicks, double radius) {
        if (intensity <= 0.0F) return;
        if (tag != null) SHAKES.removeIf(s -> tag.equals(s.tag));
        if (SHAKES.size() >= 32) return;
        Shake s = new Shake();
        s.tag = tag;
        s.pos = pos;
        s.intensity = intensity;
        s.duration = Math.max(1, durationTicks);
        s.radius = radius;
        SHAKES.add(s);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || SHAKES.isEmpty()) return;
        Iterator<Shake> it = SHAKES.iterator();
        while (it.hasNext()) {
            Shake s = it.next();
            if (++s.age >= s.duration) it.remove();
        }
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (SHAKES.isEmpty()) return;
        Vec3 cam = event.getCamera().getPosition();
        float total = 0.0F;
        for (Shake s : SHAKES) {
            double d = cam.distanceTo(s.pos);
            if (d >= s.radius) continue;
            float falloff = (float) (1.0 - d / s.radius);
            float decay = 1.0F - (s.age + (float) event.getPartialTick()) / s.duration;
            total += s.intensity * falloff * Math.max(0.0F, decay);
        }
        if (total <= 0.0F) return;
        float amp = Math.min(total, 24.0F) * 0.25F;     // intensitas 4.0 ~ 1 derajat
        float t = (System.nanoTime() / 1_000_000L) * 0.001F;
        event.setPitch(event.getPitch() + amp * Mth.sin(t * 57.0F));
        event.setYaw(event.getYaw() + amp * Mth.sin(t * 43.0F + 1.7F));
        event.setRoll(event.getRoll() + amp * 0.6F * Mth.sin(t * 71.0F + 3.1F));
    }

    private CameraShake() {}
}
