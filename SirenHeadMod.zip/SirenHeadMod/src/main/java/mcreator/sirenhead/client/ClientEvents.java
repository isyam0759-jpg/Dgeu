package mcreator.sirenhead.client;

import mcreator.sirenhead.SirenHeadMod;
import mcreator.sirenhead.config.SirenConfig;
import mcreator.sirenhead.registry.ModEffects;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Efek sisi pemain: Deafened (denging + getar) dan Terror (detak jantung). */
@Mod.EventBusSubscriber(modid = SirenHeadMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientEvents {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.isPaused()) return;

        if (p.hasEffect(ModEffects.DEAFENED.get())) {
            if (p.tickCount % 10 == 0) {
                p.level().playLocalSound(p.getX(), p.getY(), p.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME,
                        SoundSource.AMBIENT, 0.35F, 2.0F, false);
            }
            CameraShake.add("deafened", p.position(), 1.4F * SirenConfig.SHAKE_STRENGTH.get().floatValue(), 4, 8.0);
        }
        if (p.hasEffect(ModEffects.TERROR.get()) && p.tickCount % 30 == 0) {
            p.level().playLocalSound(p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_HEARTBEAT,
                    SoundSource.AMBIENT, 1.0F, 1.0F, false);
        }
    }

    private ClientEvents() {}
}
