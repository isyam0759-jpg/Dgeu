package mcreator.sirenhead.entity;

import mcreator.sirenhead.config.SirenConfig;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * Goal sederhana tanpa pathfinding: hitbox 25 blok tinggi tidak cocok dengan A* vanilla,
 * jadi Siren Head berjalan lurus ke target (pohon di jalan dihancurkan oleh breakBlocks).
 */
public final class SirenGoals {

    public static final class ChaseGoal extends Goal {
        private final SirenHeadEntity mob;

        public ChaseGoal(SirenHeadEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = mob.getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void tick() {
            LivingEntity t = mob.getTarget();
            if (t == null || mob.isBusy()) return;
            mob.getLookControl().setLookAt(t, 30.0F, 30.0F);
            double dx = t.getX() - mob.getX();
            double dz = t.getZ() - mob.getZ();
            if (dx * dx + dz * dz > 4.0) {
                mob.getMoveControl().setWantedPosition(t.getX(), t.getY(), t.getZ(), 1.0);
            }
        }
    }

    public static final class WanderGoal extends Goal {
        private final SirenHeadEntity mob;
        private Vec3 dest;
        private int timeout;

        public WanderGoal(SirenHeadEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (mob.isBusy() || mob.getTarget() != null) return false;
            if (mob.getRandom().nextInt(200) != 0) return false;
            double ang = mob.getRandom().nextDouble() * Math.PI * 2.0;
            double dist = 15.0 + mob.getRandom().nextDouble() * 25.0;
            dest = new Vec3(mob.getX() + Math.cos(ang) * dist, mob.getY(), mob.getZ() + Math.sin(ang) * dist);
            return true;
        }

        @Override
        public void start() {
            timeout = 400;
        }

        @Override
        public boolean canContinueToUse() {
            return dest != null && timeout > 0 && !mob.isBusy() && mob.getTarget() == null
                    && mob.distanceToSqr(dest.x, mob.getY(), dest.z) > 9.0;
        }

        @Override
        public void tick() {
            timeout--;
            mob.getMoveControl().setWantedPosition(dest.x, dest.y, dest.z, SirenConfig.WANDER_MULT.get());
        }

        @Override
        public void stop() {
            dest = null;
        }
    }

    private SirenGoals() {}
}
