# Siren Head: The Siren's Field — Port Java (Forge / NeoForge 1.20.1 + GeckoLib)

HANYA UNTUK PEMAKAIAN PRIBADI. Addon asli (megagatus, Kyrie guinto, ilyahopal228) berlisensi
"all rights reserved": jangan diunggah/dibagikan. Karakter Siren Head © Trevor Henderson.

## Build
1. JDK 17. Buka folder ini di IntelliJ (Gradle akan sync otomatis), atau jalankan `gradle wrapper --gradle-version 8.1.1` lalu `./gradlew build`.
2. Hasil: `build/libs/sirenhead-1.0.0.jar` -> taruh di `mods/`.
3. Wajib: Forge 47.x (atau NeoForge 1.20.1) + GeckoLib 4.4+ untuk 1.20.1.

## Isi
- Siren Head (hitbox 2x25, HP efektif 80000, boss bar), Figurehead
- Animasi GeckoLib asli: idle, walk, run, stomp, eat, talking
- Hentak (radius 50, 700 dmg), Terkam (angkat korban, 1800 dmg, heal), alarm, musik kejar, langkah + getar kamera
- Event cincin 10 Figurehead + badai petir tiap 140 dtk
- Partikel: shockwave, sound_wave, dust_cloud, debris, blood_splat, blood_drop
- Efek: Terror, Deafened
- Spawn egg, creative tab, spawn alami Overworld, lang EN/ID
- Config: config/sirenhead-common.toml (semua angka bisa diubah)
- Command (op): /sirenhead ring | clear | stomp | eat
