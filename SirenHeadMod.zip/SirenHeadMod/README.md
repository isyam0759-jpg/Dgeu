# Siren Head: The Siren's Field — Port Java (Forge / NeoForge 1.20.1 + GeckoLib)

HANYA UNTUK PEMAKAIAN PRIBADI. Addon asli (megagatus, Kyrie guinto, ilyahopal228) berlisensi
"all rights reserved": jangan diunggah/dibagikan. Karakter Siren Head © Trevor Henderson.

## Build
1. JDK 17. Buka folder ini di IntelliJ (Gradle akan sync otomatis), atau jalankan `gradle wrapper --gradle-version 8.1.1` lalu `./gradlew build`.
2. Hasil: `build/libs/sirenhead-1.0.0.jar` -> taruh di `mods/`.
3. Wajib: Forge 47.x (atau NeoForge 1.20.1) + GeckoLib 4.4+ untuk 1.20.1.

## Isi
- Siren Head (hitbox 2x25, HP efektif 80000, boss bar), Figurehead
- Animasi GeckoLib asli: idle, walk, run, stomp, eat, talking
- Hentak (radius 50, 700 dmg), Terkam (angkat korban, 1800 dmg, heal), alarm, musik kejar, langkah + getar kamera
- Event cincin 10 Figurehead + badai petir tiap 140 dtk
- Partikel: shockwave, sound_wave, dust_cloud, debris, blood_splat, blood_drop
- Efek: Terror, Deafened
- Spawn egg, creative tab, spawn alami Overworld, lang EN/ID
- Config: config/sirenhead-common.toml (semua angka bisa diubah)
- Command (op): /sirenhead ring | clear | stomp | eat

## Changelog 1.0.1
- Efek langkah/debu/cincin kejut/getar kamera kini muncul di telapak kaki, dipicu keyframe animasi jalan & lari (sinkron dengan kaki).
- Hentakan (stomp) berpusat di kaki yang menghantam; ukuran partikel diperbesar untuk mob 25 blok.
- Figurehead tanpa animasi (statis); efek jeritan di dasar tiang, cincin mengembang sampai radius damage.
- Kecepatan dicocokkan dengan animasi: kejar 0.60 (~26 blok/dtk), jalan santai ~5,5 blok/dtk.
  Key config baru: chaseSpeed & wanderSpeedMultiplier (config lama `movementSpeed` tidak dipakai lagi).

## Changelog 1.0.2
- Siren Head memakai animasi talking_idle selama klip alarm berbunyi, berhenti tepat saat klip habis (17 klip alarm kini event suara terpisah dengan durasi masing-masing).
- Alarm tidak lagi saling tumpuk: klip berikutnya baru main setelah klip sebelumnya habis + jeda.

## Changelog 1.0.3
- Saat mulai mengejar, alarm yang sedang berbunyi dihentikan dan animasi bicara dimatikan (tidak menimpa musik kejar / pose lari).
- Animasi bicara hanya untuk suara alarm; musik kejar (chasetargets) tidak memicu animasi bicara.

## Changelog 1.0.4
- Package Java diganti dari `com.sirenhead` menjadi `mcreator.sirenhead` (mod id tetap `sirenhead`, jadi dunia/config lama tetap kompatibel).
